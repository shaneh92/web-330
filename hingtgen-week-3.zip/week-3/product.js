'use-strict'
//the class of product that is being exported
export class Product {
    constructor(name, price)
    {
        this.name = name;
        this.price = price;
    }
}